package com.dulz.pc

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var root: FrameLayout
    private val prefs by lazy { getSharedPreferences("dulz_launcher", Context.MODE_PRIVATE) }
    private var overlay: View? = null
    private var currentUser: String? = null

    private data class AppItem(val icon: String, val name: String)
    private val appItems = listOf(
        AppItem("▣", "Game Store"),
        AppItem("◉", "Chrome"),
        AppItem("▤", "File Explorer"),
        AppItem("⚙", "Pengaturan"),
        AppItem("⌕", "Pencarian")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        ensureDefaultAccount()
        currentUser = prefs.getString("session_user", null)
        if (currentUser.isNullOrBlank()) showLogin() else showDesktop()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (overlay != null) closeOverlay() else if (currentUser.isNullOrBlank()) finish()
            }
        })
    }

    private fun ensureDefaultAccount() {
        if (!prefs.getBoolean("default_created", false)) {
            prefs.edit().putBoolean("default_created", true).putString("account_Dulz", "2026").apply()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float = 15f, color: Int = Color.WHITE) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        setPadding(dp(10), dp(6), dp(10), dp(6))
    }

    private fun bg(color: Int, radius: Float = 16f, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius.toInt()).toFloat()
        stroke?.let { setStroke(dp(1), it) }
    }

    private fun button(value: String, action: () -> Unit) = TextView(this).apply {
        text = value; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(12), dp(8), dp(12), dp(8)); background = bg(Color.TRANSPARENT, 14f, Color.rgb(55,55,55))
        isClickable = true; isFocusable = true; setOnClickListener { action() }
    }

    private fun editText(hintText: String) = EditText(this).apply {
        hint = hintText; setHintTextColor(Color.rgb(135,135,135)); setTextColor(Color.WHITE)
        textSize = 15f; setSingleLine(true); setPadding(dp(14), 0, dp(14), 0)
        background = bg(Color.rgb(22,22,22), 12f, Color.rgb(55,55,55))
    }

    private fun base() {
        root = FrameLayout(this); root.setBackgroundColor(Color.rgb(6,6,7)); setContentView(root)
    }

    private fun showLogin() {
        closeOverlay(); currentUser = null; base()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(28), dp(55), dp(28), dp(28)) }
        val brand = text("DULZ", 34f, Color.rgb(235,30,45)); brand.gravity = Gravity.CENTER
        box.addView(brand, LinearLayout.LayoutParams(-1, dp(55)))
        val title = text("PC Launcher 2026", 22f); title.gravity = Gravity.CENTER; box.addView(title)
        val sub = text("Desktop Android bergaya Windows", 13f, Color.rgb(160,160,160)); sub.gravity = Gravity.CENTER; box.addView(sub)
        val user = editText("Nama pengguna")
        val pass = editText("Password"); pass.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        box.addView(user, lp(52, 28)); box.addView(pass, lp(52, 10))
        box.addView(button("MASUK") {
            val u = user.text.toString().trim(); val p = pass.text.toString()
            if (u.isEmpty() || p.isEmpty()) { toast("Username dan password wajib diisi."); return@button }
            if (prefs.getString("account_$u", null) == p) { prefs.edit().putString("session_user", u).apply(); currentUser = u; showDesktop() }
            else toast("Username atau password salah.")
        }, lp(52, 18))
        box.addView(button("BUAT AKUN") { showCreateAccount() }, lp(52, 8))
        val info = text("Akun awal: Dulz / 2026\nAkun disimpan lokal di perangkat.", 12f, Color.rgb(120,120,120)); info.gravity = Gravity.CENTER
        box.addView(info, lp(-2, 22))
        root.addView(box, FrameLayout.LayoutParams(-1, -1))
    }

    private fun lp(height: Int, top: Int = 0) = LinearLayout.LayoutParams(-1, dp(height)).apply { topMargin = dp(top) }

    private fun showCreateAccount() {
        val p = panel(); p.addView(text("Buat Akun", 25f, Color.rgb(235,30,45)))
        p.addView(text("Buat akun lokal untuk launcher ini.", 13f, Color.LTGRAY))
        val u = editText("Username baru"); val a = editText("Password baru"); val b = editText("Ulangi password")
        a.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; b.inputType = a.inputType
        p.addView(u, lp(52, 18)); p.addView(a, lp(52, 10)); p.addView(b, lp(52, 10))
        p.addView(button("SIMPAN AKUN") {
            val user = u.text.toString().trim(); val pass = a.text.toString()
            if (user.length < 3 || pass.length < 4) { toast("Username minimal 3 dan password minimal 4 karakter."); return@button }
            if (pass != b.text.toString()) { toast("Password tidak sama."); return@button }
            if (prefs.contains("account_$user")) { toast("Username sudah digunakan."); return@button }
            prefs.edit().putString("account_$user", pass).apply(); toast("Akun berhasil dibuat."); showLogin()
        }, lp(52, 16))
        p.addView(button("← Kembali") { showLogin() }, lp(50, 8)); showOverlay(p)
    }

    private fun showDesktop() {
        closeOverlay(); base()
        val desktop = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(28), dp(18), dp(78)) }
        root.addView(desktop, FrameLayout.LayoutParams(-1, -1))

        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(text("DULZ", 27f, Color.rgb(235,30,45))); brand.addView(text("PC Launcher 2026", 12f, Color.rgb(150,150,150)))
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(button("⋯") { showQuickMenu() }, LinearLayout.LayoutParams(dp(52), dp(46)))
        desktop.addView(top)

        val welcome = text("Selamat datang, ${currentUser ?: "Pengguna"}", 16f); desktop.addView(welcome, lp(-2, 18))
        val date = text(SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("id", "ID")).format(Date()), 12f, Color.rgb(140,140,140)); desktop.addView(date)

        val grid = GridLayout(this).apply { columnCount = if (resources.configuration.screenWidthDp < 500) 2 else 3; useDefaultMargins = false }
        desktop.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(18) })
        appItems.forEach { item ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = bg(Color.rgb(14,14,15), 18f, Color.rgb(38,38,40)); setPadding(dp(8), dp(8), dp(8), dp(8)); isClickable = true; setOnClickListener { openApp(item.name) } }
            val ico = text(item.icon, 28f, Color.rgb(235,30,45)); ico.gravity = Gravity.CENTER; card.addView(ico)
            val name = text(item.name, 13f); name.gravity = Gravity.CENTER; card.addView(name)
            val params = GridLayout.LayoutParams().apply { width = 0; height = dp(112); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(5),dp(5),dp(5),dp(5)) }
            grid.addView(card, params)
        }

        val taskbar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(5), dp(8), dp(5)); background = bg(Color.rgb(14,14,15), 18f, Color.rgb(42,42,44)) }
        val start = button("⊞") { showStartMenu() }; taskbar.addView(start, LinearLayout.LayoutParams(dp(54), dp(50)))
        val home = button("⌂") { showDesktop() }; taskbar.addView(home, LinearLayout.LayoutParams(dp(54), dp(50)).apply { leftMargin = dp(5) })
        taskbar.addView(Space(this), LinearLayout.LayoutParams(0,1,1f))
        val clock = text("", 12f); clock.gravity = Gravity.CENTER; taskbar.addView(clock, LinearLayout.LayoutParams(dp(115), dp(50)))
        root.addView(taskbar, FrameLayout.LayoutParams(-1, dp(62), Gravity.BOTTOM).apply { leftMargin = dp(8); rightMargin = dp(8); bottomMargin = dp(8) })
        updateClock(clock)
    }

    private fun updateClock(clock: TextView) { if (isFinishing) return; clock.text = SimpleDateFormat("HH:mm\nEEE, dd MMM", Locale("id","ID")).format(Date()); clock.postDelayed({ updateClock(clock) }, 1000) }

    private fun openApp(name: String) { when (name) { "Chrome" -> openChrome(); "File Explorer" -> openExplorer(); "Pengaturan" -> showSettings(); "Pencarian" -> showSearch(); "Game Store" -> toast("Game Store siap digunakan.") } }

    private fun showStartMenu() {
        val p = panel(); p.addView(text("Dulz PC", 25f, Color.rgb(235,30,45))); p.addView(text("Mulai • Aplikasi", 12f, Color.LTGRAY))
        val search = editText("Cari aplikasi..."); p.addView(search, lp(50, 14))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; p.addView(list, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })
        fun fill(q: String) { list.removeAllViews(); appItems.filter { it.name.contains(q,true) }.forEach { item -> list.addView(button("${item.icon}   ${item.name}") { closeOverlay(); openApp(item.name) }, lp(50, 4)) }; if (list.childCount == 0) list.addView(text("Tidak ada aplikasi.",13f,Color.LTGRAY)) }
        search.addTextChangedListener(object : android.text.TextWatcher { override fun beforeTextChanged(s: CharSequence?, st:Int,c:Int,a:Int)=Unit; override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){fill(s?.toString().orEmpty())}; override fun afterTextChanged(s:android.text.Editable?)=Unit }); fill("")
        p.addView(button("⚙  Pengaturan") { showSettings() }, lp(50, 8)); p.addView(button("⇄  Ganti Akun") { logout() }, lp(50, 5)); p.addView(button("✕  Keluar") { finish() }, lp(50, 5)); showOverlay(p)
    }

    private fun showSearch() {
        val p = panel(); p.addView(text("Pencarian",25f,Color.rgb(235,30,45))); val input=editText("Cari..."); val result=text("Ketik nama aplikasi atau fitur.",13f,Color.LTGRAY)
        p.addView(input,lp(52,15)); p.addView(result,lp(-2,12)); input.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,a:Int,b:Int,c:Int)=Unit;override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){val q=s?.toString().orEmpty();result.text=if(q.isBlank())"Ketik nama aplikasi atau fitur." else appItems.filter{it.name.contains(q,true)}.joinToString("\n"){it.name}.ifBlank{"Tidak ada hasil."}};override fun afterTextChanged(s:android.text.Editable?)=Unit}); p.addView(button("← Kembali"){showDesktop()},lp(50,20));showOverlay(p)
    }

    private fun showSettings() {
        val p=panel(); p.addView(text("Pengaturan",25f,Color.rgb(235,30,45))); p.addView(text("Dulz PC Launcher 2026",13f,Color.LTGRAY))
        p.addView(button("👤  Akun: ${currentUser ?: "-"}"){toast("Akun aktif: ${currentUser ?: "-"}")},lp(50,18)); p.addView(button("⇄  Ganti Akun"){logout()},lp(50,5)); p.addView(button("⌂  Jadikan Launcher Default"){try{startActivity(Intent(Settings.ACTION_HOME_SETTINGS))}catch(_:Exception){toast("Pengaturan launcher tidak tersedia.")}},lp(50,5)); p.addView(button("ℹ  Tentang"){android.app.AlertDialog.Builder(this).setTitle("Dulz PC Launcher 2026").setMessage("Native Kotlin Android\nVersi 2026.1\n\nDibuat untuk Dulz | STRM.").setPositiveButton("OK",null).show()},lp(50,5)); p.addView(button("← Kembali"){showDesktop()},lp(50,18));showOverlay(p)
    }

    private fun showQuickMenu(){android.app.AlertDialog.Builder(this).setTitle("Dulz PC").setItems(arrayOf("Pengaturan","Ganti Akun","Keluar")){_,w->when(w){0->showSettings();1->logout();2->finish()}}.show()}
    private fun logout(){closeOverlay();prefs.edit().remove("session_user").apply();currentUser=null;showLogin()}
    private fun openChrome(){try{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com")))}catch(_:Exception){toast("Browser tidak tersedia.")}}
    private fun openExplorer(){try{startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="*/*"})}catch(_:Exception){toast("File Explorer tidak tersedia.")}}
    private fun panel()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(24),dp(20),dp(20));background=bg(Color.rgb(10,10,11),18f,Color.rgb(45,45,47))}
    private fun showOverlay(content:View){closeOverlay();val frame=FrameLayout(this).apply{setBackgroundColor(0xD9000000.toInt());setPadding(dp(12),dp(20),dp(12),dp(20))};frame.addView(content,FrameLayout.LayoutParams(-1,-1));root.addView(frame,FrameLayout.LayoutParams(-1,-1));overlay=frame;frame.alpha=0f;frame.animate().alpha(1f).setDuration(180).start()}
    private fun closeOverlay(){overlay?.let{root.removeView(it)};overlay=null}
    private fun toast(msg:String){Toast.makeText(this,msg,Toast.LENGTH_SHORT).show()}
}
