# Dulz PC Launcher 2026

Launcher Android native bergaya desktop Windows dengan taskbar, Start Menu, login, ganti akun, logout, pencarian, pengaturan, dan File Explorer.

Build debug: `gradle assembleDebug`
Application ID: `com.dulz.pc`
