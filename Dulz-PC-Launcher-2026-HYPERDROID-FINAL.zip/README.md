# Dulz-PC-Launcher-2026

Launcher Android native bergaya desktop Windows/HyperDroid.

## Fitur
- Desktop fullscreen dengan taskbar bawah.
- Start Menu dan pencarian aplikasi.
- Shortcut Aplikasi, Game, Browser, File Explorer, dan Pengaturan.
- Login, buat akun, ganti akun, dan logout.
- Wallpaper foto dari penyimpanan perangkat.
- Wallpaper video fullscreen, loop, tanpa suara.
- Reset wallpaper.
- Jam dan tanggal realtime.
- Opsi membuka pengaturan launcher default Android.

## Build
Project berada langsung di root ZIP dan dapat di-import ke Android Studio.
Gunakan JDK 17 dan Gradle 8.7.
