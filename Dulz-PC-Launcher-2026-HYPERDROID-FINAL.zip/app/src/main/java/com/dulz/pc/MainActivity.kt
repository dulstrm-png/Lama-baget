package com.dulz.pc

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var root: FrameLayout
    private lateinit var wallpaperImage: ImageView
    private lateinit var wallpaperVideo: VideoView
    private lateinit var desktopLayer: LinearLayout
    private lateinit var taskbar: LinearLayout
    private val prefs by lazy { getSharedPreferences("dulz_launcher", Context.MODE_PRIVATE) }
    private var overlay: View? = null
    private var currentUser: String? = null
    private val red = Color.rgb(235, 30, 45)
    private val white = Color.rgb(245, 245, 245)
    private val muted = Color.rgb(165, 165, 165)

    private data class AppItem(val icon: String, val name: String, val subtitle: String)
    private val appItems = listOf(
        AppItem("▦", "Aplikasi", "Semua aplikasi"),
        AppItem("⌕", "Pencarian", "Cari aplikasi & fitur"),
        AppItem("▱", "File Explorer", "Buka file perangkat"),
        AppItem("⚙", "Pengaturan", "Personalisasi launcher"),
        AppItem("◉", "Browser", "Buka browser"),
        AppItem("◆", "Game", "Game & shortcut")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideSystemBars()
        ensureDefaultAccount()
        currentUser = prefs.getString("session_user", null)
        if (currentUser.isNullOrBlank()) showLogin() else showDesktop()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (overlay != null) closeOverlay() else if (currentUser.isNullOrBlank()) finish()
            }
        })
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun hideSystemBars() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                )
        }
    }

    private fun ensureDefaultAccount() {
        if (!prefs.getBoolean("default_created", false)) {
            prefs.edit().putBoolean("default_created", true).putString("account_Dulz", "2026").apply()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(value: String, size: Float = 15f, color: Int = white) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        setPadding(dp(10), dp(6), dp(10), dp(6))
        includeFontPadding = true
    }

    private fun bg(color: Int, radius: Float = 16f, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius.toInt()).toFloat()
        stroke?.let { setStroke(dp(1), it) }
    }

    private fun button(label: String, action: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 14f
        setTextColor(white)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(8), dp(12), dp(8))
        background = bg(Color.argb(72, 255, 255, 255), 14f, Color.argb(80, 255, 255, 255))
        isClickable = true
        isFocusable = true
        setOnClickListener { action() }
    }

    private fun editText(hintText: String) = EditText(this).apply {
        hint = hintText
        setHintTextColor(Color.rgb(130, 130, 130))
        setTextColor(white)
        textSize = 15f
        setSingleLine(true)
        setPadding(dp(14), 0, dp(14), 0)
        background = bg(Color.argb(155, 20, 20, 20), 12f, Color.argb(90, 255, 255, 255))
    }

    private fun lp(height: Int, top: Int = 0) = LinearLayout.LayoutParams(-1, if (height < 0) height else dp(height)).apply { topMargin = dp(top) }

    private fun base() {
        root = FrameLayout(this)
        root.setBackgroundColor(Color.rgb(4, 4, 5))
        setContentView(root)
    }

    private fun showLogin() {
        closeOverlay(); currentUser = null; base()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(28), dp(42), dp(28), dp(28))
        }
        val brand = tv("DULZ", 38f, red); brand.gravity = Gravity.CENTER
        box.addView(brand, lp(58))
        val title = tv("PC Launcher 2026", 23f); title.gravity = Gravity.CENTER; box.addView(title)
        val sub = tv("Desktop Android bergaya Windows", 13f, muted); sub.gravity = Gravity.CENTER; box.addView(sub)
        val user = editText("Nama pengguna")
        val pass = editText("Password")
        pass.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        box.addView(user, lp(52, 24)); box.addView(pass, lp(52, 10))
        box.addView(button("MASUK") {
            val u = user.text.toString().trim(); val p = pass.text.toString()
            if (u.isEmpty() || p.isEmpty()) { toast("Username dan password wajib diisi."); return@button }
            if (prefs.getString("account_$u", null) == p) {
                prefs.edit().putString("session_user", u).apply(); currentUser = u; showDesktop()
            } else toast("Username atau password salah.")
        }, lp(52, 18))
        box.addView(button("BUAT AKUN") { showCreateAccount() }, lp(52, 8))
        val info = tv("Akun awal: Dulz / 2026\nAkun disimpan lokal di perangkat.", 12f, Color.rgb(125,125,125)); info.gravity = Gravity.CENTER
        box.addView(info, lp(-2, 20))
        root.addView(box, FrameLayout.LayoutParams(-1, -1))
    }

    private fun showCreateAccount() {
        val p = panel(); p.addView(tv("Buat Akun", 25f, red)); p.addView(tv("Buat akun lokal untuk launcher ini.", 13f, muted))
        val u = editText("Username baru"); val a = editText("Password baru"); val b = editText("Ulangi password")
        a.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD; b.inputType = a.inputType
        p.addView(u, lp(52, 18)); p.addView(a, lp(52, 10)); p.addView(b, lp(52, 10))
        p.addView(button("SIMPAN AKUN") {
            val user = u.text.toString().trim(); val pass = a.text.toString()
            if (user.length < 3 || pass.length < 4) { toast("Username minimal 3 dan password minimal 4 karakter."); return@button }
            if (pass != b.text.toString()) { toast("Password tidak sama."); return@button }
            if (prefs.contains("account_$user")) { toast("Username sudah digunakan."); return@button }
            prefs.edit().putString("account_$user", pass).apply(); toast("Akun berhasil dibuat."); showLogin()
        }, lp(52, 16))
        p.addView(button("← Kembali") { showLogin() }, lp(50, 8)); showOverlay(p)
    }

    private fun showDesktop() {
        closeOverlay(); base()
        wallpaperImage = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(Color.rgb(5,5,6)); alpha = 0.96f }
        wallpaperVideo = VideoView(this).apply { setBackgroundColor(Color.BLACK); visibility = View.GONE }
        root.addView(wallpaperImage, FrameLayout.LayoutParams(-1,-1))
        root.addView(wallpaperVideo, FrameLayout.LayoutParams(-1,-1))
        applyWallpaper()

        val shade = View(this).apply { setBackgroundColor(Color.argb(42, 0, 0, 0)) }
        root.addView(shade, FrameLayout.LayoutParams(-1,-1))

        desktopLayer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(92))
        }
        root.addView(desktopLayer, FrameLayout.LayoutParams(-1,-1))

        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(tv("DULZ", 27f, red)); brand.addView(tv("PC Launcher", 12f, Color.rgb(205,205,205)))
        header.addView(brand, LinearLayout.LayoutParams(0,-2,1f))
        header.addView(button("⋮") { showQuickMenu() }, LinearLayout.LayoutParams(dp(52),dp(46)))
        desktopLayer.addView(header)

        val welcome = tv("Selamat datang, ${currentUser ?: "Pengguna"}", 18f)
        desktopLayer.addView(welcome, lp(-2, 22))
        desktopLayer.addView(tv("Desktop • ${SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("id","ID")).format(Date())}", 12f, Color.rgb(210,210,210)))

        val title = tv("Aplikasi favorit", 14f, Color.rgb(220,220,220)); desktopLayer.addView(title, lp(-2, 16))
        val grid = GridLayout(this).apply {
            columnCount = if (resources.configuration.screenWidthDp < 480) 2 else 3
            rowCount = 2
            alignmentMode = GridLayout.ALIGN_BOUNDS
            useDefaultMargins = false
        }
        desktopLayer.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        appItems.forEach { item -> addAppCard(grid, item) }
        ensureTaskbar()
    }

    private fun addAppCard(grid: GridLayout, item: AppItem) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = bg(Color.argb(100, 10, 10, 12), 18f, Color.argb(100, 255,255,255))
            setPadding(dp(8),dp(8),dp(8),dp(8))
            isClickable = true
            setOnClickListener { openApp(item.name) }
        }
        val ico = tv(item.icon, 28f, red); ico.gravity = Gravity.CENTER; card.addView(ico)
        val name = tv(item.name, 13f); name.gravity = Gravity.CENTER; card.addView(name)
        val sub = tv(item.subtitle, 10f, muted); sub.gravity = Gravity.CENTER; card.addView(sub)
        val params = GridLayout.LayoutParams().apply {
            width = 0; height = dp(122)
            columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            setMargins(dp(5),dp(5),dp(5),dp(5))
        }
        grid.addView(card, params)
    }

    private fun buildTaskbar(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7),dp(6),dp(7),dp(6))
            background = bg(Color.argb(220, 15,15,17), 20f, Color.argb(110,255,255,255))
            elevation = dp(8).toFloat()
        }
    }

    private fun addTaskButton(bar: LinearLayout, icon: String, label: String, action: () -> Unit) {
        val v = button(icon) { action() }
        v.contentDescription = label
        bar.addView(v, LinearLayout.LayoutParams(dp(48),dp(48)).apply { rightMargin = dp(5) })
    }

    private fun ensureTaskbar() {
        if (::taskbar.isInitialized && taskbar.parent != null) root.removeView(taskbar)
        taskbar = buildTaskbar()
        addTaskButton(taskbar, "⊞", "Mulai") { showStartMenu() }
        addTaskButton(taskbar, "⌂", "Beranda") { showDesktop() }
        addTaskButton(taskbar, "▱", "File Explorer") { openExplorer() }
        addTaskButton(taskbar, "⌕", "Pencarian") { showSearch() }
        addTaskButton(taskbar, "⚙", "Pengaturan") { showSettings() }
        val spacer = Space(this); taskbar.addView(spacer, LinearLayout.LayoutParams(0,1,1f))
        val net = tv("●  ONLINE", 9f, Color.rgb(145,235,160)); net.gravity = Gravity.CENTER
        taskbar.addView(net, LinearLayout.LayoutParams(dp(74),dp(48)))
        val clock = tv("", 11f); clock.gravity = Gravity.CENTER
        taskbar.addView(clock, LinearLayout.LayoutParams(dp(100),dp(48)))
        root.addView(taskbar, FrameLayout.LayoutParams(-1,dp(66),Gravity.BOTTOM).apply { leftMargin=dp(8); rightMargin=dp(8); bottomMargin=dp(8) })
        updateClock(clock)
    }

    private fun updateClock(clock: TextView) {
        if (isFinishing) return
        clock.text = SimpleDateFormat("HH:mm\nEEE, dd MMM", Locale("id","ID")).format(Date())
        clock.postDelayed({ updateClock(clock) }, 1000)
    }

    private fun openApp(name: String) {
        when(name) {
            "Aplikasi" -> showApps()
            "Pencarian" -> showSearch()
            "File Explorer" -> openExplorer()
            "Pengaturan" -> showSettings()
            "Browser" -> openChrome()
            "Game" -> showGame()
        }
    }

    private fun showApps() {
        val p=panel(); p.addView(tv("Aplikasi",25f,red)); p.addView(tv("Semua aplikasi dan shortcut",13f,muted))
        appItems.forEach { item -> p.addView(button("${item.icon}   ${item.name}\n${item.subtitle}") { closeOverlay(); openApp(item.name) }, lp(58,7)) }
        p.addView(button("← Kembali") { showDesktop() }, lp(50,18)); showOverlay(p)
    }

    private fun showGame() {
        val p=panel(); p.addView(tv("Game",25f,red)); p.addView(tv("Area game / shortcut",13f,muted))
        p.addView(button("＋  Tambah shortcut game") { toast("Fitur shortcut game siap dikembangkan.") }, lp(52,18))
        p.addView(button("🎮  Game Center") { toast("Game Center dibuka.") }, lp(52,8))
        p.addView(button("← Kembali") { showDesktop() }, lp(50,18)); showOverlay(p)
    }

    private fun showStartMenu() {
        val p=panel(); p.addView(tv("Dulz PC",26f,red)); p.addView(tv("Mulai • ${currentUser ?: "Pengguna"}",12f,muted))
        val search=editText("Cari aplikasi..."); p.addView(search,lp(50,14))
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; p.addView(list,LinearLayout.LayoutParams(-1,0,1f).apply{topMargin=dp(8)})
        fun fill(q:String){ list.removeAllViews(); appItems.filter{it.name.contains(q,true)||it.subtitle.contains(q,true)}.forEach{item->list.addView(button("${item.icon}   ${item.name}\n${item.subtitle}"){closeOverlay();openApp(item.name)},lp(54,4))}; if(list.childCount==0) list.addView(tv("Tidak ada hasil.",13f,muted)) }
        search.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int)=Unit;override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){fill(s?.toString().orEmpty())};override fun afterTextChanged(s:android.text.Editable?)=Unit}); fill("")
        p.addView(button("⚙  Pengaturan") { showSettings() },lp(50,8)); p.addView(button("⇄  Ganti Akun") { logout() },lp(50,5)); p.addView(button("✕  Keluar") { finish() },lp(50,5)); showOverlay(p)
    }

    private fun showSearch() {
        val p=panel(); p.addView(tv("Pencarian",25f,red)); val input=editText("Cari aplikasi, fitur..."); val result=tv("Ketik kata kunci untuk mencari.",13f,muted)
        p.addView(input,lp(52,15)); p.addView(result,lp(-2,12))
        input.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,a:Int,b:Int,c:Int)=Unit;override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){val q=s?.toString().orEmpty();result.text=if(q.isBlank())"Ketik kata kunci untuk mencari." else appItems.filter{it.name.contains(q,true)||it.subtitle.contains(q,true)}.joinToString("\n"){it.name}.ifBlank{"Tidak ada hasil."}};override fun afterTextChanged(s:android.text.Editable?)=Unit})
        p.addView(button("← Kembali"){showDesktop()},lp(50,20));showOverlay(p)
    }

    private fun showSettings() {
        val p=panel(); p.addView(tv("Pengaturan",25f,red)); p.addView(tv("Personalisasi Dulz PC Launcher",13f,muted))
        p.addView(tv("WALLPAPER",11f,Color.rgb(210,210,210)).apply{setPadding(dp(10),dp(18),dp(10),dp(4))})
        p.addView(button("🖼  Pilih Foto Wallpaper") { pickWallpaper(false) },lp(52,6))
        p.addView(button("▶  Pilih Video Wallpaper") { pickWallpaper(true) },lp(52,6))
        p.addView(button("↺  Reset Wallpaper") { prefs.edit().remove("wallpaper_uri").remove("wallpaper_type").apply(); toast("Wallpaper direset."); showDesktop() },lp(52,6))
        p.addView(tv("SISTEM",11f,Color.rgb(210,210,210)).apply{setPadding(dp(10),dp(18),dp(10),dp(4))})
        p.addView(button("👤  Akun: ${currentUser ?: "-"}") { toast("Akun aktif: ${currentUser ?: "-"}") },lp(50,6))
        p.addView(button("⇄  Ganti Akun") { logout() },lp(50,6))
        p.addView(button("⌂  Jadikan Launcher Default") { try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) } catch(_:Exception){toast("Pengaturan launcher tidak tersedia.")} },lp(50,6))
        p.addView(button("ℹ  Tentang") { AlertDialog.Builder(this).setTitle("Dulz PC Launcher 2026").setMessage("Native Kotlin Android\nVersi 2026.1\n\nDesktop launcher dengan taskbar, start menu dan wallpaper foto/video.").setPositiveButton("OK",null).show() },lp(50,6))
        p.addView(button("← Kembali") { showDesktop() },lp(50,18)); showOverlay(p)
    }

    private fun pickWallpaper(video: Boolean) {
        val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type=if(video)"video/*" else "image/*";addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)}
        startActivityForResult(intent, if(video) 2002 else 2001)
    }

    @Deprecated("Android framework callback")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode==RESULT_OK && data?.data!=null && (requestCode==2001||requestCode==2002)) {
            val uri=data.data!!
            try{contentResolver.takePersistableUriPermission(uri,data.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){}
            prefs.edit().putString("wallpaper_uri",uri.toString()).putString("wallpaper_type",if(requestCode==2002)"video" else "image").apply()
            toast("Wallpaper berhasil diubah.")
            showDesktop()
        }
    }

    private fun applyWallpaper() {
        val uriString=prefs.getString("wallpaper_uri",null)
        val type=prefs.getString("wallpaper_type","image")
        wallpaperImage.visibility=View.VISIBLE; wallpaperVideo.visibility=View.GONE
        if(uriString.isNullOrBlank()) {
            wallpaperImage.setImageDrawable(GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(9,9,11),Color.rgb(38,7,10),Color.rgb(5,5,6))))
            return
        }
        val uri=Uri.parse(uriString)
        if(type=="video") {
            wallpaperImage.visibility=View.GONE; wallpaperVideo.visibility=View.VISIBLE
            wallpaperVideo.setVideoURI(uri)
            wallpaperVideo.setOnPreparedListener { mp -> mp.isLooping=true; mp.setVolume(0f,0f); wallpaperVideo.start() }
            wallpaperVideo.setOnErrorListener { _,_,_-> toast("Video wallpaper tidak dapat diputar."); prefs.edit().remove("wallpaper_uri").remove("wallpaper_type").apply(); showDesktop(); true }
        } else {
            try{wallpaperImage.setImageURI(uri)}catch(_:Exception){toast("Foto wallpaper tidak dapat dibuka.")}
        }
    }

    private fun showQuickMenu(){AlertDialog.Builder(this).setTitle("Dulz PC").setItems(arrayOf("Pengaturan","Ganti Akun","Keluar")){_,w->when(w){0->showSettings();1->logout();2->finish()}}.show()}
    private fun logout(){closeOverlay();prefs.edit().remove("session_user").apply();currentUser=null;showLogin()}
    private fun openChrome(){try{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com")))}catch(_:Exception){toast("Browser tidak tersedia.")}}
    private fun openExplorer(){try{startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="*/*"})}catch(_:Exception){toast("File Explorer tidak tersedia.")}}
    private fun panel()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(24),dp(20),dp(20));background=bg(Color.argb(238,10,10,11),20f,Color.argb(100,255,255,255))}
    private fun showOverlay(content:View){closeOverlay();val frame=FrameLayout(this).apply{setBackgroundColor(0xB5000000.toInt());setPadding(dp(12),dp(18),dp(12),dp(18))};frame.addView(content,FrameLayout.LayoutParams(-1,-1));root.addView(frame,FrameLayout.LayoutParams(-1,-1));overlay=frame;frame.alpha=0f;frame.animate().alpha(1f).setDuration(180).start()}
    private fun closeOverlay(){overlay?.let{root.removeView(it)};overlay=null}
    private fun toast(msg:String){Toast.makeText(this,msg,Toast.LENGTH_SHORT).show()}
}
